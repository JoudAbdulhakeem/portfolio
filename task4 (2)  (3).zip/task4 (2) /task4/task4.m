% Create a cell array to store image file paths
imagePaths = {
    '/MATLAB Drive/archive (1)/anatomy_detection.pt'
    % Add paths for additional images here
};

% Loop through each image
for i = 1:length(imagePaths)
    % Read the medical image
    originalImage = imread(imagePaths{i});

    % Display the original image
    figure;
    imshow(originalImage);
    title(['Original Image - ', num2str(i)]);

    % Convert the image to grayscale if it's in color
    if size(originalImage, 3) == 3
        grayscaleImage = rgb2gray(originalImage);
    else
        grayscaleImage = originalImage;
    end

    % Step 1: Histogram Equalization
    equalizedImage = histeq(grayscaleImage);

    % Display the equalized image
    figure;
    imshow(equalizedImage);
    title(['Equalized Image - ', num2str(i)]);

    % Step 2: Select a region of interest (ROI)
    disp('Please draw a rectangle to select the region of interest.');
    roi = round(getrect);  % The user selects a rectangle using the mouse

    % Extract the ROI from the original image
    roiImage = grayscaleImage(roi(2):roi(2)+roi(4), roi(1):roi(1)+roi(3));

    % Step 3: Calculate the histogram of the ROI
    roiHist = imhist(roiImage);

    % Step 4: Enhance the selected bins in the overall image histogram
    enhancedImage = grayscaleImage;

    % Define enhancement factors for different techniques
    multiplicativeFactor = 1.1;
    adaptiveFactor = 0.5;

    % Apply multiplicative enhancement to the entire image histogram
    enhancedImageHistogram = imhist(enhancedImage);
    enhancedImageHistogram(1:length(roiHist)) = enhancedImageHistogram(1:length(roiHist)) * multiplicativeFactor;

    % Convert the image to double before applying adapthisteq
    doubleImage = im2double(grayscaleImage);

    % Apply adaptive histogram equalization to the entire image
    adaptiveEqualizedImage = adapthisteq(doubleImage, 'ClipLimit', adaptiveFactor);

    % Ensure all images are of the same class
    enhancedImage = double(histeq(grayscaleImage, enhancedImageHistogram)) + adaptiveEqualizedImage + double(imadjust(grayscaleImage, [0.1 0.9]));

    % Display the enhanced image
    figure;
    imshow(enhancedImage, []);
    title(['Enhanced Image - ', num2str(i)]);

    % Step 5: Apply Log Transformation
    logTransformedImage = log(1 + double(grayscaleImage));

    % Display the log-transformed image
    figure;
    imshow(logTransformedImage, []);
    title(['Log Transformed Image - ', num2str(i)]);

    % Step 6: Apply Negative Filter
    negativeImage = 255 - grayscaleImage;

    % Display the negative-filtered image
    figure;
    imshow(negativeImage);
    title(['Negative Filtered Image - ', num2str(i)]);
end
